<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cambio de rol exitoso</title>
    <link rel="stylesheet" href="/css/compraExitosa.css">
    <link rel="shortcut icon" href="/assets/icono.jpg" type="image/x-icon">
</head>

<body>
    <header class="header">
        <a href="/view/viewVendedor.php">Inicio</a>
        <h1 class="header__h1">BIENVENIDO A GRUPO B&C </h1>
    </header>
    <main class="main">
        <section class="main__section">
            <h2>Producto Registrado Exitosamente</h2>
        </section>
    </main>
</body>

</html>