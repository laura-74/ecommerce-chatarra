<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/css/viewVendedor.css">
    <link rel="shortcut icon" href="/assets/icono.jpg" type="image/x-icon">


</head>

<body>
    <header class="header">
    <a href="/index.php">Inicio</a>
        <h1 class="header__h1">BIENVENIDO VENDEDOR</h1>
    </header>
    <main class="main">
            <a class="main__section__a1" href="/view/nuevosProductos.php">
                <div class="main__section__div">
                    <p>Ingresar <br> nuevos <br> productos</p>
                </div>
            </a>
            <a class="main__section__a2" href="/view/tablaProductos.php">
                <div class="main__section__div">
                    <p>Tabla<br>productos</p>
                </div>
            </a>
    </main>
</body>

</html>